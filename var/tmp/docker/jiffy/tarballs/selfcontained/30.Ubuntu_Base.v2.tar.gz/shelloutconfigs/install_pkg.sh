#!/usr/bin/env bash

apt-get update --fix-missing
apt-get install -y pwgen wget curl git-core \
htop sysstat rng-tools haveged

/etc/init.d/haveged restart
update-rc.d haveged defaults
