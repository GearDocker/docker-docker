name "wrapper"

description "The wrapper cookbook self contained config Base.1,67cd28f673b23e23e96c504decd9a099.6eca0903592b5e74f077313f74faf023"

run_list "recipe[custom::default]"

