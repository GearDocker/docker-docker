#Group: Ubuntu/14.04/DockerInDocker/Install
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/14.04/DockerInDocker/Install/CHROOTFILES/usr/local
#version: 1
#file_check_hash: b1f5daeb976e0deec823f6e77da33c97
#file_ref_hash: 0b8202a616ad9c6e3dc8731a4d7c4467
directory '/usr/local' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/14.04/DockerInDocker/Install
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/14.04/DockerInDocker/Install/CHROOTFILES/usr/local/bin
#version: 1
#file_check_hash: fa240150a0c7512602658fa0fda0f642
#file_ref_hash: 351c98fa65cac711770dcec75908852e
directory '/usr/local/bin' do
    owner 'root'
    group 'root'
    mode '0755'
end

#Group: Ubuntu/14.04/DockerInDocker/Install
#file: /opt/jiffy/gary/Public/Configs/Ubuntu/14.04/DockerInDocker/Install/CHROOTFILES/usr/local/bin/dind
#version: 1
#file_check_hash: f4534d69abf0a66847ef7ecf7df1aee5
#file_ref_hash: 9e0c25d3fed68cebbd703adb8297af38
#md5sum_file: cec1b62ad7228ae39e2caa8d4d5c86fc
#filename: dind 
cookbook_file '/usr/local/bin/dind' do
    source 'cec1b62ad7228ae39e2caa8d4d5c86fc'
    owner 'root'
    group 'root'
    mode '0755'
end

