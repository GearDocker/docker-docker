name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/14.04/DockerInDocker/Install.3,0942459368d5e4d1d08012c6ab9b6448.21f75dd0dab91477da5176677df312f7"

run_list "recipe[custom::default]"

