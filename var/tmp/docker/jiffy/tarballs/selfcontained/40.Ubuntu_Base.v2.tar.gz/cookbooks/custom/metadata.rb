#Created by jiffy automatically.
name             "custom"
maintainer       "YOUR_COMPANY_NAME"
maintainer_email "YOUR_EMAIL"
license          "All rights reserved"
description      "Installs/Configures custom"
version          "0.0.1"
