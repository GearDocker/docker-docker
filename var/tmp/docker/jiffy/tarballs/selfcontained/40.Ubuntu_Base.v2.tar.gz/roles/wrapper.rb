name "wrapper"

description "The wrapper cookbook self contained config Ubuntu/Base.2,fc7f77cf19b1357eb2b3607cc1692b8c.0efa16468298495565a1985fe2188585"

run_list "recipe[custom::default]"

